# robosoft
Terminal for programming (offline and online) robots from [Intelitek](https://www.intelitek.com/), formerly knonwn as Eshed Robotec, using the ACL language.

This is the new home of the Robosoft Simulator previosully hosted at SourceForge.

For legacy reasons the source forge repository will be keeped hosting the last stable binary build:

https://sourceforge.net/projects/aclsimulator/

