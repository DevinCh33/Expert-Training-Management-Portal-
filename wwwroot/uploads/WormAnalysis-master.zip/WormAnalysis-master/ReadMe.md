
# WormAnalysis
Source Code to the question: https://stackoverflow.com/questions/37820629/centerline-of-a-polygonal-blob-binary-image

Tracking the centerline of a blob from a binary image.

![asd](https://github.com/gabyx/WormAnalysis/blob/master/SkeletonTest/wormTest2.jpg)
![asd](https://github.com/gabyx/WormAnalysis/blob/master/SkeletonTest/wormTest2OutputGraph.png)

The picture set in the AnaylsisTest folder can not be provided due to copyright issues.
If they are needed, I can ask for approval to add them.
