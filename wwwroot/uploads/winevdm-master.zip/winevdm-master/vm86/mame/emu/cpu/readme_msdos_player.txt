Based on MAME 0.152.
