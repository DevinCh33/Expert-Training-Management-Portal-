#define IDS_MANIFEST                   101
